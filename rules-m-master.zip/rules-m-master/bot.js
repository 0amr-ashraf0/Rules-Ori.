const Discord = require("discord.js");
const client = new Discord.Client();
client.on('message', message => {
            if (message.content.startsWith("r!rules")) {
     let embed = new Discord.RichEmbed()
.addField('     اولا ' ,' ممنوع السب ')
.addField('     ثانيا ' ,' لا تسوي سبام  ')
.addField('     ثالثا ' ,' لا تزعج الاخرين ')
.addField('    رابعا' ,' ممنوع الاعلانات ')
.addField('    خامسا' ,' احترم الاخرين ')
.addField('    سادسا' ,' لا تنشر في الشات او بل خاص ')
.addField('    سابعا' ,' لا تنشر روابط! ')
.addField('    ثامنا' ,' لا تسوي سبام ايموجي ')
.addField('    تاسعا' ,' لا تطلب رتبه الاداره ! ')
.setColor('RANDOM')
  message.channel.sendEmbed(embed);
    }
});



client.login(process.env.BOT_TOKEN);
